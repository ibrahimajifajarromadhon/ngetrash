<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-04-27 09:30:38 --> UTF-8 Support Enabled
DEBUG - 2024-04-27 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-27 09:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-27 09:30:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-04-27 09:30:38 --> Total execution time: 0.1622
