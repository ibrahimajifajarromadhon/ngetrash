<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
DEBUG - 2024-04-26 14:30:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-26 14:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-26 14:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-04-26 14:30:33 --> 
DEBUG - 2024-04-26 14:30:33 --> Menghapus data daur ulang dengan ID: 61
DEBUG - 2024-04-26 14:30:33 --> UTF-8 Support Enabled
DEBUG - 2024-04-26 14:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-26 14:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-26 14:30:33 --> Total execution time: 0.0855
